//
//  ViewController.swift
//  CreditCardList
//
//  Created by young june Park on 2022/01/09.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

