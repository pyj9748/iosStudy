//
//  LoginViewController.swift
//  LoginSample
//
//  Created by young june Park on 2022/01/08.
//

import UIKit
import Firebase
import GoogleSignIn
class LoginViewController:UIViewController{
    
    @IBOutlet weak var emailLoginButton: UIButton!
    @IBOutlet weak var googleLoginButton: GIDSignInButton!
    @IBOutlet weak var appleLoginButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        [emailLoginButton,googleLoginButton,appleLoginButton].forEach{
            
            $0?.layer.borderWidth = 1
            $0?.layer.borderColor = UIColor.white.cgColor
            $0?.layer.cornerRadius = 30
            
            
        }
    }
    @IBAction func tapGoogleLoginButton(_ sender: UIButton) {
        
        
    }
    @IBAction func tapAppleLoginButton(_ sender: UIButton) {
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = true
        
    }
    
    
}
