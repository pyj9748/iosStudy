//
//  MainViewController.swift
//  LoginSample
//
//  Created by young june Park on 2022/01/09.
//

import UIKit
import FirebaseAuth
class MainViewContoller:UIViewController{
    
    @IBOutlet weak var welcomeLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        
        let email = Auth.auth().currentUser?.email ?? "고객"
        welcomeLabel.text = "환영합니다.\n\(email)님"
    }
    @IBAction func tapLogoutButton(_ sender: UIButton) {
        let firebaseAuth = Auth.auth()
        
        do {
            try firebaseAuth.signOut()
            self.navigationController?.popToRootViewController(animated: true)
        } catch let signOutError as NSError {
            
            print("ERROR : signout \(signOutError.localizedDescription)")
        }
        
        
        
    }
}
